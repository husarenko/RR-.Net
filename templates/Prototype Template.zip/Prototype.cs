﻿namespace PrototypePattern
{
    public abstract class $safeitemname$
    {
        public abstract $safeitemname$ Clone();
    }

    public class ConcretePrototype1 : $safeitemname$
    {
        public string Id { get; set; }

        public ConcretePrototype1(string id)
        {
            Id = id;
        }

        public override $safeitemname$ Clone()
        {
            return ($safeitemname$)MemberwiseClone();
        }

        public override string ToString()
        {
            return $"ConcretePrototype1: Id = {Id}";
        }
    }

    public class Client
    {
        private $safeitemname$ _prototype;

        public Client($safeitemname$ prototype)
        {
            _prototype = prototype;
        }

        public void Operation()
        {
            $safeitemname$ clone = _prototype.Clone();
            Console.WriteLine(clone.ToString());
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            ConcretePrototype1 prototype = new ConcretePrototype1("1234");
            Client client = new Client(prototype);
            client.Operation();
        }
    }
}
