﻿using System;
using System.Collections.Generic;

namespace CompositePattern
{
    abstract class Component
    {
        public abstract void Operation();
    }

    class Leaf : Component
    {
        public override void Operation()
        {
            Console.WriteLine("Leaf operation");
        }
    }

    class $safeitemname$ : Component
    {
        private List<Component> _children = new List<Component>();

        public override void Operation()
        {
            Console.WriteLine("$safeitemname$ operation");
            foreach (var child in _children)
            {
                child.Operation();
            }
        }

        public void Add(Component component)
        {
            _children.Add(component);
        }

        public void Remove(Component component)
        {
            _children.Remove(component);
        }

        public Component GetChild(int index)
        {
            return _children[index];
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            $safeitemname$ root = new $safeitemname$();
            root.Add(new Leaf());

            $safeitemname$ subtree = new $safeitemname$();
            subtree.Add(new Leaf());
            root.Add(subtree);

            root.Operation();
        }
    }
}
